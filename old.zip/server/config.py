BACKUP_PATH="E:\\PY\\PY\\replica\\server\\backup"
SERVER_HOST="127.0.0.1"
SERVER_PORT=60000
