import os,socket,json,logging,threading,time
from config import *
from utils.server_utils import *


def main():
    server=socket.socket()
    server.bind((SERVER_HOST,SERVER_PORT))
    while True:
        try:
            print("Binding")
            server.listen()
            conn,addr=server.accept()
            data=[]
            while True:
                conn.settimeout(3)
                b=conn.recv(1024)
                if not b:
                    break
                data.append(b)
            print(data)
            data=b"".join(data)
            print(data.decode())
                
        except Exception as e:
            if e==KeyboardInterrupt:
                exit()
            logging.exception(e)

if __name__ == '__main__':
    t1=threading.Thread(target=main,daemon=True)
    t1.start()
    while True:
        try:
            time.sleep(1)
        except:
            exit(1)
