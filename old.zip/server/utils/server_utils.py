import os
from datetime import datetime


def create_snapshot(backup_path:str, directory_tree:list[tuple]):
    if not os.path.exists(backup_path):
        os.mkdir(backup_path)
    os.chdir(backup_path)
    snapshot_timestamp = str(datetime.now().strftime("%Y_%m_%d_%H_%M_%S"))
    os.mkdir(snapshot_timestamp)
    os.chdir(snapshot_timestamp)
    for path,directory_name,files in directory_tree:
        if not os.path.exists(path):
            os.mkdir(path)
        