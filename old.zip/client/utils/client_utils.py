import os

def get_directory_tree(top: str)-> list[tuple]:
    dirs=os.walk(top=top)
    res=[]
    for dir in dirs:
        res.append(dir)
    return res