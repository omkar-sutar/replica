import os
import socket
import time
import logging
import json
import threading
from config import *
from utils.client_utils import *


def start_backup():
    client=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((SERVER_HOST,SERVER_PORT))
    #First generate directory tree
    path=PATH[0]
    if not os.path.exists(path):
        raise Exception("Invalid backup path")
    directory_tree=get_directory_tree(PATH[0])
    jsoned=json.dumps(directory_tree)
    client.sendall(jsoned.encode())
    client.recv(1024)
    for directory_path,subdirectories,files in directory_tree:
        for file in files:
            filepath=os.path.join(directory_path,file)
            logging.info(f"Sending file {filepath}")
            with open(filepath) as f:
                client.sendfile(f,0)

    client.close()
    

def main():
    while True:
        try:
            start_backup()
        except Exception as e:
            logging.exception(e)
        time.sleep(TIME_INTERVAL)

if __name__ == '__main__':
    t1=threading.Thread(target=main,daemon=True)
    t1.start()
    while True:
        try:
            time.sleep(1)
        except:
            exit(1)