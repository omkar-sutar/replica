PATH=[
    "E:\\PY\\PY\\replica\\client\\Demo\\",
]
SERVER_HOST="127.0.0.1"
SERVER_PORT=60000
TIME_INTERVAL=10